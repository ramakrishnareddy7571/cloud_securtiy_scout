from scan_public_s3 import check_s3_public_buckets

def lambda_handler(event, context):
    findings = check_s3_public_buckets()
    print("Scan complete.")
    return {
        'statusCode': 200,
        'body': f"{len(findings)} public findings found."
    }
