from scan_iam_risks import run_iam_scan

def lambda_handler(event, context):
    run_iam_scan()
    return {
        'statusCode': 200,
        'body': 'IAM scan complete.'
    }
