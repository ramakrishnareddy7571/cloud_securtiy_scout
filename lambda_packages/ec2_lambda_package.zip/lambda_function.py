from scan_ec2_sg import scan_ec2_security_groups

def lambda_handler(event, context):
    scan_ec2_security_groups()
